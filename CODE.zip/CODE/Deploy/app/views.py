from django.shortcuts import render
from keras.models import load_model
from PIL import Image, ImageOps
import numpy as np
from tensorflow import keras

from . import forms
from .models import UserImageModel

# Create your views here.
def home(request):
    print("HI")
    if request.method == "POST":
        form = forms.UserImageForm(files=request.FILES)
        if form.is_valid():
            print('HIFORM')
            form.save()
        obj = form.instance
        #('obj',obj)
        result = UserImageModel.objects.latest('id')
        result = result.image           
        models = keras.models.load_model('E:/Diwakar/Project/Deep Learning/ITPDL17/Deploy/app/lenet.h5')
        from tensorflow.keras.preprocessing import image
        test_image = image.load_img('E:/Diwakar/Project/Deep Learning/ITPDL17/Deploy/media/' + str(result),
                                    target_size=(256, 256))
        test_image = image.img_to_array(test_image)
        test_image = np.expand_dims(test_image, axis=0)
        result = models.predict(test_image)
        prediction = result[0]
        prediction = list(prediction)
        classes = ['angry', 'disgust', 'happy', 'sad','surprise']
        output = zip(classes, prediction)
        output = dict(output)
        if output['angry'] == 1.0:
            a='Angry'
        elif output['disgust'] == 1.0:
            a='Disgust'   
        elif output['happy'] == 1.0:
            a='Happy'
        elif output['sad'] == 1.0:
            a="Sad"
        elif output['surprise'] == 1.0:
            a="Surprise"
        
        return render(request, 'app/index.html',{'form':form,'obj':obj,'predict':a})
    else:
        form = forms.UserImageForm()
    return render(request, 'app/index.html',{'form':form})

